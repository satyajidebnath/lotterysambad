// Verify download-once and failure preservation without requiring Poppler locally.
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const path=require('node:path');
const os=require('node:os');
const vm=require('node:vm');
async function check(){
 const temporary=await fs.mkdtemp(path.join(os.tmpdir(),'lottery-build-test-'));
 let downloads=0,conversions=0;
 const mockChild={execFileSync(command,args){
  assert.equal(command,'pdftoppm');conversions++;
  const header=Buffer.alloc(24);header.writeUInt32BE(0x89504e47,0);header.writeUInt32BE(1200,16);header.writeUInt32BE(1800,20);
  require('node:fs').writeFileSync(args.at(-1)+'-1.png',header);
 }};
 try{
  await fs.mkdir(path.join(temporary,'scripts'));await fs.writeFile(path.join(temporary,'index.html'),'<h1>Test</h1>');
  const context={require:n=>n==='node:child_process'?mockChild:require(n),__dirname:path.join(temporary,'scripts'),module:{exports:{}},console,Buffer,Intl,Date,AbortSignal,
   fetch:async()=>{downloads++;return {ok:true,arrayBuffer:async()=>Buffer.from('%PDF-1.7 mock')};}};
  vm.runInNewContext(await fs.readFile(path.join(__dirname,'build-site.cjs'),'utf8'),context);
  await context.module.exports.build();await context.module.exports.build();
  assert.equal(downloads,1);assert.equal(conversions,1);
  const file=path.join(temporary,'published','result.json');const result=JSON.parse(await fs.readFile(file,'utf8'));
  assert.equal(result.pages[0].width,1200);assert.equal(result.pages[0].height,1800);
  result.date='2000-01-01';await fs.writeFile(file,JSON.stringify(result));
  context.fetch=async()=>({ok:true,arrayBuffer:async()=>Buffer.from('<html>not published</html>')});
  await assert.rejects(context.module.exports.build(),/not available/);
  assert.equal(JSON.parse(await fs.readFile(file,'utf8')).date,'2000-01-01');
  console.log('Passed: conversion output, one download across repeated runs, and preservation on unavailable PDF.');
 }finally{await fs.rm(temporary,{recursive:true,force:true});}
}
check().catch(e=>{console.error(e);process.exitCode=1;});
