const fs=require('node:fs/promises');
const path=require('node:path');
const {execFileSync}=require('node:child_process');
const root=path.resolve(__dirname,'..'),output=path.join(root,'published');
function resultDate(date=new Date()){
 const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Kolkata',day:'2-digit',month:'2-digit',year:'numeric'}).formatToParts(date);
 const get=t=>parts.find(p=>p.type===t).value;
 return {date:`${get('year')}-${get('month')}-${get('day')}`,filename:`MN${get('day')}${get('month')}${get('year').slice(-2)}.PDF`};
}
async function build(){
 const today=resultDate();await fs.mkdir(output,{recursive:true});let previous;
 try{previous=JSON.parse(await fs.readFile(path.join(output,'result.json'),'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;}
 if(previous?.date===today.date){
  for(const page of previous.pages)await fs.access(path.join(output,page.src));
  await fs.copyFile(path.join(root,'index.html'),path.join(output,'index.html'));
  console.log('Today’s images already exist; no download or conversion.');return;
 }
 const source=`https://www.lotterysambad.com/fetchtoday.php?filename=${today.filename}`;
 const response=await fetch(source,{signal:AbortSignal.timeout(45000)});
 if(!response.ok)throw Error(`PDF source returned HTTP ${response.status}; keeping the previous website.`);
 const pdf=Buffer.from(await response.arrayBuffer());
 if(!pdf.subarray(0,1024).includes(Buffer.from('%PDF-')))throw Error('Today’s PDF is not available yet; keeping the previous website.');
 const temporary=await fs.mkdtemp(path.join(root,'.result-build-'));
 try{
  const pdfPath=path.join(temporary,today.filename);await fs.writeFile(pdfPath,pdf);
  const prefix=today.filename.replace('.PDF','');
  execFileSync('pdftoppm',['-png','-scale-to','1800',pdfPath,path.join(temporary,prefix)],{timeout:120000,stdio:'inherit'});
  const names=(await fs.readdir(temporary)).filter(n=>n.endsWith('.png')).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true}));
  if(!names.length)throw Error('No pages were converted.');
  const pages=[];
  for(const name of names){
   const image=await fs.readFile(path.join(temporary,name));
   if(image.readUInt32BE(0)!==0x89504e47)throw Error('Invalid PNG output.');
   pages.push({src:name,width:image.readUInt32BE(16),height:image.readUInt32BE(20)});
   await fs.copyFile(path.join(temporary,name),path.join(output,name));
  }
  await fs.writeFile(path.join(output,'result.json'),JSON.stringify({...today,source,pages},null,2)+'\n');
  await fs.copyFile(path.join(root,'index.html'),path.join(output,'index.html'));
  for(const name of await fs.readdir(output))if(name.endsWith('.png')&&!names.includes(name))await fs.unlink(path.join(output,name));
  console.log(`Downloaded ${today.filename} and generated ${pages.length} image(s).`);
 }finally{await fs.rm(temporary,{recursive:true,force:true});}
}
if(require.main===module)build().catch(e=>{console.error(e.message);process.exitCode=1;});
module.exports={resultDate,build};
