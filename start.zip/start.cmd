@echo off
cd /d "%~dp0"
node server.cjs --open
pause
