const http = require('node:http');
const fs = require('node:fs/promises');
const path = require('node:path');

function filenameForToday(date = new Date()) {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Kolkata', day: '2-digit', month: '2-digit', year: '2-digit'
  }).formatToParts(date);
  const part = type => parts.find(item => item.type === type).value;
  return `MN${part('day')}${part('month')}${part('year')}.PDF`;
}

const pendingDownloads = new Map();
const downloadsDirectory = path.join(__dirname, 'downloads');

async function downloadPDF(filename) {
  if (pendingDownloads.has(filename)) return pendingDownloads.get(filename);
  const operation = loadOrDownloadPDF(filename);
  pendingDownloads.set(filename, operation);
  try {
    return await operation;
  } finally {
    pendingDownloads.delete(filename);
  }
}

async function loadOrDownloadPDF(filename) {
  const destination = path.join(downloadsDirectory, filename);
  try {
    const saved = await fs.readFile(destination);
    if (saved.subarray(0, 1024).includes(Buffer.from('%PDF-'))) return saved;
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
  const url = `https://www.lotterysambad.com/fetchtoday.php?filename=${filename}`;
  const response = await fetch(url, { signal: AbortSignal.timeout(45000) });
  if (!response.ok) throw new Error(`Source returned HTTP ${response.status}.`);
  const buffer = Buffer.from(await response.arrayBuffer());
  if (!buffer.subarray(0, 1024).includes(Buffer.from('%PDF-'))) {
    throw new Error('The source has not returned a PDF. Today’s result may not be published yet.');
  }
  await fs.mkdir(downloadsDirectory, { recursive: true });
  const temporary = `${destination}.${process.pid}.tmp`;
  try {
    await fs.writeFile(temporary, buffer);
    await fs.rename(temporary, destination);
  } finally {
    await fs.rm(temporary, { force: true });
  }
  return buffer;
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  try {
    if (req.method !== 'GET') {
      res.writeHead(405); return res.end('Method not allowed');
    }
    if (url.pathname === '/api/pdf') {
      const filename = filenameForToday();
      const pdf = await downloadPDF(filename);
      res.writeHead(200, { 'Content-Type': 'application/pdf', 'Cache-Control': 'no-store',
        'Content-Disposition': `inline; filename="${filename}"` });
      return res.end(pdf);
    }
    if (['/vendor/pdf.min.mjs', '/vendor/pdf.worker.min.mjs'].includes(url.pathname)) {
      res.writeHead(200, { 'Content-Type': 'text/javascript; charset=utf-8' });
      return res.end(await fs.readFile(path.join(__dirname, url.pathname.slice(1))));
    }
    if (url.pathname === '/' || url.pathname === '/index.html') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return res.end(await fs.readFile(path.join(__dirname, 'index.html')));
    }
    res.writeHead(404); res.end('Not found');
  } catch (error) {
    console.error(error.message);
    res.writeHead(502, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(JSON.stringify({ error: `Could not download today's PDF: ${error.message}` }));
  }
});
if (require.main === module) {
  server.on('error', error => {
    console.error(`Cannot start server: ${error.message}`);
    process.exitCode = 1;
  });
  server.listen(8787, '127.0.0.1', () => {
    const address = 'http://127.0.0.1:8787';
    console.log(`Open ${address} — keep this window open while viewing results.`);
    if (process.argv.includes('--open')) {
      require('node:child_process').spawn('cmd.exe', ['/c', 'start', '', address], {
        windowsHide: true, stdio: 'ignore'
      }).on('error', error => console.error(`Open ${address} manually: ${error.message}`));
    }
  });
}
module.exports = { filenameForToday, server, downloadPDF };
