# Lottery Sambad — GitHub Actions + GitHub Pages

Actions generates today's MNDDMMYY.PDF URL using India's date, downloads it and
converts every page to PNG with Poppler. Pages serves those images to everyone.
There is no PDF conversion or source-site request in visitors' browsers.

## Setup

1. Create a public GitHub repository with default branch `main`.
2. Upload `index.html`, `scripts/build-site.cjs`, and `.github/workflows/daily-result.yml`, preserving their folders. Include this README and `.gitignore` when using Git. Do not upload the old local server, vendor, downloads or Chrome profile folders.
3. Under **Settings → Pages → Source**, select **GitHub Actions**.
4. Under **Settings → Actions → General → Workflow permissions**, allow **Read and write permissions**. Branch protection must allow the workflow bot to push generated files to `main`.
5. Open **Actions → Publish lottery result → Run workflow** on `main`.
6. Find the website link under **Settings → Pages** or the workflow deployment.

No Cloudflare account, API key or custom secret is required.

## Daily updates

The job checks hourly at minute 17 UTC. After the first successful conversion each
day, it commits `published/` to the repository. All later runs reuse those files
without downloading or converting again. Simultaneous jobs are serialized.
If the PDF is unavailable, the run fails and the previous website stays online;
the next scheduled run retries. The first deployment needs a successful download.
Successful runs deploy the saved site again, allowing failed deployments to recover
without downloading the PDF again. Do not remove `published/`, which is the cache.

GitHub schedules can be delayed and public-repository schedules are disabled after
60 days without repository activity. Monitor Actions. Current published files keep
only the latest result, but old images remain in Git history. If a result is
corrected, delete `published/result.json` and run the workflow to download again.

For local builds, install Node.js 22+ and Poppler (`pdftoppm`), then run:

```sh
node scripts/build-site.cjs
```

Preview the generated `published/` folder using any static web server. Opening the
root HTML file directly does not include the generated result.
